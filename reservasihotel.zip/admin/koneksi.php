<?php

class database
{	
	function __construct()
	{
		@mysql_connect("mysql.idhostinger.com", "u200383227_web", "mir12345");
		@mysql_select_db("u200383227_web");
	}

	function tampil_data($tabel){ 
	$data = mysql_query("select * from $tabel");
	while($d = mysql_fetch_array($data)){
		$hasil[] = $d;
	}
	return $hasil;
  	}

  	function tampil_data3($tabel1,$tabel2,$tabel3){ 
	$data = mysql_query("SELECT A.kd_pemesanan, C.no_kamar, C.nama_kamar, A.nama_lengkap, A.no_identitas, A.no_hp, C.harga, A.alamat FROM $tabel2 B join $tabel1 A on B.kd_pemesanan=A.kd_pemesanan join $tabel3 C on B.kd_pesan=C.kd_kamar");
	while($d = mysql_fetch_array($data)){
		$hasil[] = $d;
	}
	return $hasil;
  	}


  	function inputkamar($kd_kamar,$nama_kamar,$tipe_kamar,$jumlah_kasur,$no_kamar,$harga,$keterangan)
	{
		mysql_query("insert into kamar values('$kd_kamar','$nama_kamar','$tipe_kamar','$jumlah_kasur','$no_kamar','$harga','$keterangan')");
	}

	function hapuskamar($kd_kamar)
	{
		mysql_query("delete from kamar where kd_kamar='$kd_kamar'");
	}

	function editkamar($kd_kamar)
	{
		$data = mysql_query("select * from kamar where kd_kamar='$kd_kamar'");
		while($d = mysql_fetch_array($data)){
			$hasil[] = $d;
		}
		return $hasil;
	}

	function updatekamar($kd_kamar,$nama_kamar,$tipe_kamar,$jumlah_kasur,$no_kamar,$harga,$keterangan)
	{
		mysql_query("update kamar set nama_kamar='$nama_kamar', tipe_kamar='$tipe_kamar', jumlah_kasur='$jumlah_kasur', no_kamar='$no_kamar', harga='$harga', keterangan='$keterangan' where kd_kamar='$kd_kamar'");
	}

}

?>		