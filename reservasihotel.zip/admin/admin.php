<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="..\css\bootstrap.min.css">
</head>
<body>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
        <div class="panel panel-default">       
        <div class="panel-heading">
        <legend><h1><span class="glyphicon glyphicon-log-in"></span> Login</h1></legend>
        <div class="panel-body">
            <form action="index.php" method="POST" role="form"> 
            <div class="form-group">
                    <label for=""><span class="glyphicon glyphicon-user"></span> Username</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                    <label for=""><span class="glyphicon glyphicon-lock"></span> Password</label>
                    <input type="Password" class="form-control" name="password" id="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary" name="login">Login</button>
            </form>
        </div>
        </div>
        </div>
        </div>
    </div>
</div>
</body>
</html>