<?php 
include('akses.php');
include 'koneksi.php';
$db = new database();
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Home</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>

   <link rel="stylesheet" href="css/style.css">
   <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>
    <script src="js/index.js"></script>
  
</head>

<body style="background-color: #2ecc71">
  <div id="wrapper">
  <div class="overlay"></div>

  <!-- Sidebar -->
  <nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
    <ul class="nav sidebar-nav">
      <li class="sidebar-brand">
        <a href="#">
            <i class="fa fa-fw fa-user"></i><?php echo $_SESSION['admin']; ?>
                    </a>
      </li>
      <li>
        <a href="home.php"><i class="fa fa-fw fa-home"></i> Home</a>
      </li>
      <li>
        <a href="datakamar.php"><i class="fa fa-fw fa-folder"></i> Data Kamar</a>
      </li>
      <li>
        <a href="datapemesanan.php"><i class="fa fa-fw fa-folder"></i> Data Pemesanan</a>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-fw fa-cog"></i> Pengaturan <span class="caret"></span></a>
        <ul class="dropdown-menu" role="menu">
          <li class="dropdown-header">Opsi</li>
          <li><a href="logout.php"><i class="fa fa-fw fa-times"></i>Logout</a></li>          
        </ul>
      </li>
     
    </ul>
  </nav>
  <div id="page-content-wrapper">
    <button type="button" class="hamburger is-closed animated fadeInLeft" data-toggle="offcanvas">
            <span class="hamb-top"></span>
            <span class="hamb-middle"></span>
            <span class="hamb-bottom"></span>
          </button>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-lg-offset-2">
          <h1 class="page-header">Edit Data Kamar</h1>
          <br>          
  <div class="panel">      
  <form action="proses.php?aksi=update" method="post">
<?php
foreach($db->editkamar($_GET['kd_kamar']) as $d){
?>
  <table class="table table-hover">
  <tr>        
    <th>Kode Kamar</th>
    <th><input type="text" name="kd_kamar" value="<?php echo $d['kd_kamar'] ?>" readonly ></th>
  </tr>

  <tr>
    <th>Nama Kamar</th>
    <th><input type="text" name="nama_kamar" value="<?php echo $d['nama_kamar'] ?>"></th>
  </tr>
  <tr>
    <th>Tipe Kamar</th>
    <th><input type="text" name="tipe_kamar" value="<?php echo $d['tipe_kamar'] ?>"></th>
  </tr>
  <tr>
    <th>Jumlah Kasur</th>
    <th><input type="text" name="jumlah_kasur" value="<?php echo $d['jumlah_kasur'] ?>"></th>
  </tr>
  <tr>
    <th>No Kamar</th>
    <th><input type="text" name="no_kamar" value="<?php echo $d['no_kamar'] ?>"></th>
  </tr>  
  <tr>  
      <th>Harga</th>
      <th><input type="text" name="harga" value="<?php echo $d['harga'] ?>"</th>
  </tr> 
  <tr> 
       <th>Keterangan</th>
      <th><input type="text" name="keterangan" value="<?php echo $d['keterangan'] ?>"</th>
  </tr>
   <tr>
    <th></th>
    <th><input type="submit" value="Simpan"></th>
  </tr>
   
</table>
<?php }  ?>
</form>
  </div>
  
        </div>
      </div>
    </div>
  </div>
  <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>