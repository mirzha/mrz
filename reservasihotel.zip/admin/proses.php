<?php
include 'koneksi.php';
$db = new database();

 $aksi = $_GET['aksi'];

 if($aksi == "tambah")
 {
 	$db->inputkamar($_POST['kd_kamar'],$_POST['nama_kamar'],$_POST['tipe_kamar'],$_POST['jumlah_kasur'],$_POST['no_kamar'],$_POST['harga'],$_POST['keterangan']);
 	header("location:datakamar.php");
 }

 elseif($aksi == "hapus")
 {
 	$db->hapuskamar($_GET['kd_kamar']);
	header("location:datakamar.php");
 }

  elseif($aksi == "update")
  {
 	$db->updatekamar($_POST['kd_kamar'],$_POST['nama_kamar'],$_POST['tipe_kamar'], $_POST['jumlah_kasur'], $_POST['no_kamar'],$_POST['harga'],$_POST['keterangan']);
 	header("location:datakamar.php");
 }
?>